/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cardwargame;

public class Player {

    private PlayerHand playerHand;
    private String playerName;

    public PlayerHand getHand() {
        return this.playerHand;
    }

    public void setHand(PlayerHand player_hand) {
        this.playerHand = player_hand;
    }

    public Player(String player_name) {
        this.playerName = player_name;
    }

    public String getPlayerName() {
        return this.playerName;
    }

    public void setPlayerName(String player_name) {
        this.playerName = player_name;
    }

}
