/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cardwargame;

import java.util.Collections;
import java.util.List;
import java.util.ArrayList;

/**
 * Deck of cards. We have 52 cards in total that will made up of 4 suites of
 * cards
 */
public class CardsDeck {
    private final List<CardWarGame> gameCards = new ArrayList<>();

    CardsDeck() {
        generateCardDeck();
    }

    private void generateCardDeck() {
        for (CardsSuit suit : CardsSuit.values()) {
            for (CardRank rank : CardRank.values()) {
                gameCards.add(new CardWarGame(rank, suit));
            }
        }
    }

    /**
     * Now we will shuffles the deck to move cards on random positions
     */
    public void shuffleCards() {
        Collections.shuffle(this.gameCards);
    }

    /**
     * @return card as a List Type
     */
    public List<CardWarGame> getGameCards() {
        return this.gameCards;
    }

    /**
     * @return how many cards left in the deck
     */
    public int getCardsCount() {
        int size = this.gameCards.size();
        return size;
    }

    /**
     * In this function we will Deal a card at the top of deck & then we will remove
     * it from deck.
     * 
     * @return card from the end of the arrayList(Top Card)
     */
    public CardWarGame dealCardFromTop() {
        int size = this.gameCards.size() - 1;
        return this.gameCards.remove(size);
    }

    /**
     * This function will add a card at the bottom of deck.
     * 
     * @param card_war_game is the card that will be added at the bottom of the
     *                      deck,
     */
    public void addCardAtBottom(CardWarGame card_war_game) {
        this.gameCards.add(0, card_war_game);
    }

    /**
     * @return string that will contain all the cards in a order
     */
    @Override
    public String toString() {
        String orderedCards = this.gameCards.toString();
        return orderedCards;
    }
}
