/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cardwargame;

import java.util.List;
import java.util.Scanner;

public class Game {

    // This will be used to print statics of game
    private static final GameStats gameStats = new GameStats();
    private CardsDeck deck;

    /**
     * Player One
     */
    private Player playerOne;

    /**
     * Player Two
     */
    private Player playerTwo;

    // Play the Game
    public void playGame() {
        gameStats.greeting();

        Scanner in = new Scanner(System.in);

        // Get the name of First Player
        System.out.print("Please enter first player name : ");
        String playerOneName = in.nextLine();
        this.playerOne = new Player(playerOneName);

        // Get the name of Second Player
        System.out.print("\nPlease enter second player name : ");
        String playerTowName = in.nextLine();
        this.playerTwo = new Player(playerTowName);

        // Print message that game is starting
        gameStats.StartNewGameMessage(playerOne, playerTwo);

        // Generate a new deck of cards
        deck = new CardsDeck();

        // Shuffle deck
        deck.shuffleCards();

        // Create and set hands fror player one
        playerOne.setHand(new PlayerHand());

        // Create and set hands fror player two
        playerTwo.setHand(new PlayerHand());

        // dealCards to hand
        dealCardsInGame(playerOne.getHand());
        dealCardsInGame(playerTwo.getHand());

        gameStats.Header(playerOne, playerTwo);

        // Display result of game
        int maxGameRounds = 27;
        Player winnerPlayer = null;
        while (war(playerOne, playerTwo, null)) {
            maxGameRounds--;
            // Now we will check hands for winner
            if (playerOne.getHand().sizeofHand() == 0) {
                // Player two is winner
                winnerPlayer = playerTwo;
                break;
            } else if (playerTwo.getHand().sizeofHand() == 0) {
                // Player one is winner
                winnerPlayer = playerOne;
                break;
            }

            // Check if max round is negative then break the game
            if (maxGameRounds < 0) {
                break;
            }
        }

        if (winnerPlayer != null) {

            // Any one of two player wins the game
        } else if (playerOne.getHand().sizeofHand() > playerTwo.getHand().sizeofHand()) { // If playerOne wins
            winnerPlayer = playerOne;
        } else if (playerTwo.getHand().sizeofHand() > playerOne.getHand().sizeofHand()) { // If playerTwo wins
            winnerPlayer = playerTwo;
        } else {

            // If no player wins and game is draw
            gameStats.announceDrawGame();
            return;
        }
        gameStats.announceGameWinner(winnerPlayer);
    }

    // Deal 26 cards to each hand in alternating order
    public void dealCardsInGame(PlayerHand hand) {
        for (int i = 0; i < 26; i++) {
            hand.addCardToTop(deck.dealCardFromTop());
        }
    }

    // Now models a war between playerOne and playerTwo. If the war results in a
    // war, three cards from each player are placed in the prize queue and the war
    // is continued recursively.
    public boolean war(Player playerOne, Player playerTwo, PlayerHand pan) {

        // Now both players will show a card from the top of deck
        // These remaining cards will be stored in an array.
        CardWarGame playerOneFaceUpCard = playerOne.getHand().removeCardFromTopOfDeck();
        if (playerOneFaceUpCard == null) {
            return false;
        }

        CardWarGame playerTwoFaceUpCard = playerTwo.getHand().removeCardFromTopOfDeck();
        if (playerTwoFaceUpCard == null) {
            return false;
        }

        // If game ties and its case of war then each of two player will add thre cards
        // to pan and the forth card is evaluated
        if (pan == null) {
            pan = new PlayerHand();
        }
        pan.addCardToTop(playerOneFaceUpCard);
        pan.addCardToTop(playerTwoFaceUpCard);

        int resultRound = playerOneFaceUpCard.compareTo(playerTwoFaceUpCard);
        switch (resultRound) {
            case 0:
                gameStats.announceGameWarRound();

                // Now each player of game will add three cards to the prizeHand
                List<CardWarGame> warPlayerOnePan = playerOne.getHand().takeCards(3);
                if (warPlayerOnePan == null) {
                    return false;
                }
                pan.addCardsToTop(warPlayerOnePan);

                List<CardWarGame> warPlayerTwoPan = playerTwo.getHand().takeCards(3);
                if (warPlayerTwoPan == null) {
                    return false;
                }
                pan.addCardsToTop(warPlayerTwoPan);

                return war(playerOne, playerTwo, pan);
            case 1:
                // Now give all the cards on table to playerOne
                // playerOne will add both faceUp cards to bottom of his deck
                playerOne.getHand().mergeHandCards(pan);
                gameStats.announceEachRoundWinner(playerOne, playerOneFaceUpCard, playerTwo, playerTwoFaceUpCard,
                        playerOne.getPlayerName());
                break;
            case -1:
                // Now give all the cards on table to playerTwo
                // playerTwo will add both faceUp cards to bottom of his deck
                playerTwo.getHand().mergeHandCards(pan);
                gameStats.announceEachRoundWinner(playerOne, playerOneFaceUpCard, playerTwo, playerTwoFaceUpCard,
                        playerTwo.getPlayerName());
                break;
        }

        return true;
    }
}