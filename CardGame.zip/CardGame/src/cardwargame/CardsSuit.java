/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package cardwargame;

/*
Representation of the four suits in a standard deck of cards.
*/
public enum CardsSuit {
    HEARTS("Hearts", "H"),
    SPADES("Spades", "S"),
    DIAMONDS("Diamonds", "D"),
    CLUBS("Clubs", "C");

    private final String suitName;
    private final String suitSymbol;

    CardsSuit(String suit_name, String suit_symbol) {
        this.suitName = suit_name;
        this.suitSymbol = suit_symbol;
    }

    /*
     * 
     * Get the symbol of the suit.
     * Example: DIAMONDS = D
     * 
     * @return the shorthand symbol of the suit
     */
    public String getSuitSymbol() {
        return this.suitSymbol;
    }

    /*
     * 
     * Get the name of the suit.
     * Example: Spades = Spades
     * 
     * @return the full name of the suit
     */
    public String getSuitName() {
        return this.suitName;
    }

    /*
     * 
     * Get the shorthand symbol of the suit.
     * Example: DIAMONDS = D
     * 
     * @return the shorthand symbol of the suit
     */
    @Override
    public String toString() {
        return this.getSuitSymbol();
    }

}
