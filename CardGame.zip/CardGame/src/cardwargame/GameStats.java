/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cardwargame;

public class GameStats {

    public void greeting() {
        System.out.println("It is the Card War Game" +
                "\n\tWe have automated this game and it will be played till deck will be empty" +
                "\n\tIn this game, you must enter the names of the two players who will play this game.\n");
        System.out.println("By hitting enter verify that you are prepared to play the game.\n");
    }

    public void StartNewGameMessage(Player player_one, Player player_two) {
        System.out.printf("%s AND %s,let's Start the Game!\n\n\n", player_one.getPlayerName(),
                player_two.getPlayerName());
    }

    public void Header(Player player_one, Player player_two) {
        String winnerTheRound = "Winner Of This Round";
        String header = "Cards In Hand";
        System.out.printf("\n%-20s   %-20s %-20s   %-20s %-20s \n\n", player_one.getPlayerName(), header,
                player_two.getPlayerName(), header, winnerTheRound);
    }

    // This function will print winner after each round & then final round winner
    public void announceEachRoundWinner(Player player_one, CardWarGame card_one, Player player_two,
            CardWarGame card_two,
            String winnerOfRound) {
        System.out.printf("%-20s   %-20s %-20s   %-20s %s is winner of this round.\n", card_one.toString(),
                player_one.getHand().sizeofHand(), card_two.toString(), player_two.getHand().sizeofHand(),
                winnerOfRound);
    }

    // This function will print the war game round
    public void announceGameWarRound() {
        System.out.println("\n\nWow its a WAR! Its a tie round & War was re-initiated again.\n\n");
    }

    // This function will print message if game draws
    public void announceDrawGame() {
        System.out.printf("\nWeldone buddies, Game is draw. Let's play again\n\n");
    }

    // This function will print the winner of game round
    public void announceGameWinner(Player player) {
        System.out.printf("\nCongratulations!! %s is the winner of the game!\n\n", player.getPlayerName());
    }

}
