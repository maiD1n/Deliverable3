/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cardwargame;

import java.util.ArrayList;
import java.util.List;

/**
 * PlayerHand is Representative of an individual card of cards. In our game War
 * will starts with 26 cards.
 */
public class PlayerHand {

    // players individual cards
    private final List<CardWarGame> gameCards;

    public PlayerHand() {
        this.gameCards = new ArrayList<>();
    }

    /**
     * Merge another hand into this one
     *
     * @param other_cards
     */
    public void mergeHandCards(PlayerHand other_cards) {
        for (CardWarGame cardWarGame : other_cards.gameCards) {
            this.addCardToBottom(cardWarGame);
        }
    }

    /**
     * This function will Take list N cards
     *
     * @param num_of_cards
     * @return list of cards
     */
    public List<CardWarGame> takeCards(int num_of_cards) {
        if (num_of_cards > this.sizeofHand()) {
            return null;
        }

        List<CardWarGame> outCards = new ArrayList<>();
        for (int i = 0; i < num_of_cards; i++) {
            outCards.add(this.gameCards.remove(this.sizeofHand() - 1));
        }

        return outCards;
    }

    /**
     * @param card_war_game single Card object added to end of Array
     */
    public void addCardToTop(CardWarGame card_war_game) {
        if (card_war_game == null) {
            throw new NullPointerException("Cannot add a null card to a deck of cards.");
        }
        gameCards.add(card_war_game);
    }

    /**
     * This function will adds more than one card at a time to hand
     *
     * @param cards cards added to hand as array
     */
    public void addCardsToTop(List<CardWarGame> cards) {
        this.gameCards.addAll(cards);
    }

    /**
     * @param card_war_game single Card object added to beginning of Array
     */
    public void addCardToBottom(CardWarGame card_war_game) {
        gameCards.add(0, card_war_game);
    }

    /**
     * This function will removes the card from the last index of the array
     * 
     * @return
     */
    public CardWarGame removeCardFromTopOfDeck() {
        if (sizeofHand() < 1) {
            return null;
        }
        return gameCards.remove(sizeofHand() - 1);
    }

    /**
     * This function will removes card from the first index of the array
     * 
     * @return
     */
    public CardWarGame removeCardFromBottomOfDeck() {
        if (sizeofHand() < 1) {
            return null;
        }
        return gameCards.remove(0);
    }

    /**
     * @return the number of cards in the hand.
     */
    public int sizeofHand() {
        return gameCards.size();
    }

}