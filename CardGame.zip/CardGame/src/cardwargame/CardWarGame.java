/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cardwargame;

import java.util.Objects;

/**
 * This class models a simple card guessing game
 * 
 * @author Mai Dinh, Simranpreet Kaur, Divyansh Thakur
 */
public class CardWarGame implements Comparable<CardWarGame> {

    private final String gameCard;
    private final CardsSuit suit;
    private final CardRank rank;

    CardWarGame(CardRank card_rank, CardsSuit card_suit) {
        if (card_rank == null || card_suit == null) { // Check if rank or suit is null
            throw new NullPointerException();
        }
        this.suit = card_suit;
        this.rank = card_rank;
        this.gameCard = String.format("%s%s", card_rank.toString(), card_suit.getSuitSymbol());
    }

    /**
     * @return Enum name of a card objects rank
     * 
     *         example: THREE
     */
    public CardRank getCardRank() {
        return this.rank;
    }

    /**
     * @return shorthand of an objects rank
     * 
     *         example: THREE = 3
     */
    public String getRankValue() {
        return this.rank.toString();
    }

    /**
     * @return Enum name of a card objects suit
     * 
     *         example: HEARTS
     */
    public CardsSuit getCardSuitName() {
        return this.suit;
    }

    /**
     * @return shorthand of an objects suit
     * 
     *         example: HEARTS = H
     */
    public String getCardSuitSymbol() {
        return this.suit.getSuitSymbol();
    }

    /**
     * @return point value of a card object
     * 
     *         example: THREE = 3
     */
    public Integer getCardPoints() {
        return this.rank.getRankValuePoint();
    }

    /**
     * @return shorthand of an objects rank and suit
     */
    public String getCardInfo() {
        return this.gameCard;
    }

    /**
     * @param card_war_game is object of CardWarGame
     * @return 1 if point value of this Card > other, -1 if
     *         point value of this Card < cardGame and 0 if equal
     */
    @Override
    public int compareTo(CardWarGame card_war_game) {
        return this.getCardPoints().compareTo(card_war_game.getCardPoints());
    }

    /**
     * @param card_war_game is object of CardWarGame
     * @return true if string value of two different
     *         card's suit are equal
     */
    public boolean checkIsSuitSame(CardWarGame card_war_game) {
        boolean iSuitSame = this.suit.equals(card_war_game.suit);
        return iSuitSame;
    }

    /**
     * @param card_war_game is object of CardWarGame
     * @return true if two different card's rank are equal
     */
    public boolean checkIsRankSame(CardWarGame card_war_game) {
        boolean isRankSame = this.rank.equals(card_war_game.rank);
        return isRankSame;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (!CardWarGame.class.isAssignableFrom(obj.getClass())) {
            return false;
        }
        final CardWarGame other = (CardWarGame) obj;
        return this.suit == other.suit && this.rank == other.rank;
    }

    @Override
    public int hashCode() {
        int hashValue = 3;
        hashValue = 89 * hashValue + Objects.hashCode(this.rank);
        hashValue = 89 * hashValue + Objects.hashCode(this.suit);
        return hashValue;
    }

    /**
     * @return full written name of a card object
     *         * Example: Queen of Hearts
     */
    @Override
    public String toString() {
        String nameOfRank = this.rank.getRankName();
        String nameOfSuit = this.suit.getSuitName();
        String fullWrittenName = nameOfRank + " of " + nameOfSuit;
        return fullWrittenName;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Game game = new Game();
        game.playGame();
    }
}
