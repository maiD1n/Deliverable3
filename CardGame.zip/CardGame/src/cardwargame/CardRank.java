/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package cardwargame;

/**
 * This class represents the 13 possible ranks in a deck of cards.
 * Out of each card, Ace will have the highest value & 2 will have the lowest
 * one.
 */
public enum CardRank {
    TWO("Two", 2),
    THREE("Three", 3),
    FOUR("Four", 4),
    FIVE("Five", 5),
    SIX("Six", 6),
    SEVEN("Seven", 7),
    EIGHT("Eight", 8),
    NINE("Nine", 9),
    TEN("Ten", 10),
    JACK("Jack", 11),
    QUEEN("Queen", 12),
    KING("King", 13),
    ACE("Ace", 14);

    private final String rankName;
    private final int rankValuePoint;

    CardRank(String rank_name, int point_value) {
        this.rankName = rank_name;
        this.rankValuePoint = point_value;
    }

    /**
     * Example: QUEEN = Queen
     * 
     * @return the longhand name of the rank
     */
    public String getRankName() {
        return this.rankName;
    }

    /**
     * Example: QUEEN = 12
     * 
     * @return the integer value of the rank, from 2 to 14
     */
    public int getRankValuePoint() {
        return this.rankValuePoint;
    }

    /**
     * Example: QUEEN = Q
     * 
     * @return the shorthand name of the rank
     */
    @Override
    public String toString() {
        if (this.getRankValuePoint() > 10) {
            return this.getRankName().substring(0, 1);
        }
        return String.valueOf(this.getRankValuePoint());
    }

}
