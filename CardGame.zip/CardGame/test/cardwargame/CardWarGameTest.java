package cardwargame;

import org.junit.Assert;
import org.junit.Test;

public class CardWarGameTest {
	private static final CardWarGame testCard1 = new CardWarGame(CardRank.TWO, CardsSuit.SPADES);
	private static final CardWarGame testCard2 = new CardWarGame(CardRank.TEN, CardsSuit.DIAMONDS);
	private static final CardWarGame testCard3 = new CardWarGame(CardRank.QUEEN, CardsSuit.CLUBS);
	private static final CardWarGame testCard4 = new CardWarGame(CardRank.ACE, CardsSuit.HEARTS);

	@Test
	public void getCardRankTest() {
		Assert.assertEquals(CardRank.TWO, testCard1.getCardRank());
		Assert.assertEquals(CardRank.TEN, testCard2.getCardRank());
		Assert.assertEquals(CardRank.QUEEN, testCard3.getCardRank());
		Assert.assertEquals(CardRank.ACE, testCard4.getCardRank());
	}

	@Test
	public void getRankValueTest() {
		Assert.assertEquals(CardRank.TWO.toString(), testCard1.getRankValue());
		Assert.assertEquals(CardRank.TEN.toString(), testCard2.getRankValue());
		Assert.assertEquals(CardRank.QUEEN.toString(), testCard3.getRankValue());
		Assert.assertEquals(CardRank.ACE.toString(), testCard4.getRankValue());
	}

	@Test
	public void getCardSuitNameTest() {
		Assert.assertEquals(CardsSuit.SPADES, testCard1.getCardSuitName());
		Assert.assertEquals(CardsSuit.DIAMONDS, testCard2.getCardSuitName());
		Assert.assertEquals(CardsSuit.CLUBS, testCard3.getCardSuitName());
		Assert.assertEquals(CardsSuit.HEARTS, testCard4.getCardSuitName());
	}

	@Test
	public void getCardSuitSymbolTest() {
		Assert.assertEquals(CardsSuit.SPADES.getSuitSymbol(), testCard1.getCardSuitSymbol());
		Assert.assertEquals(CardsSuit.DIAMONDS.getSuitSymbol(), testCard2.getCardSuitSymbol());
		Assert.assertEquals(CardsSuit.CLUBS.getSuitSymbol(), testCard3.getCardSuitSymbol());
		Assert.assertEquals(CardsSuit.HEARTS.getSuitSymbol(), testCard4.getCardSuitSymbol());
	}

	@Test
	public void getGameCatdTest() {
		Assert.assertEquals("2S", testCard1.getCardInfo());
		Assert.assertEquals("10D", testCard2.getCardInfo());
		Assert.assertEquals("QC", testCard3.getCardInfo());
		Assert.assertEquals("AH", testCard4.getCardInfo());
	}

	@Test
	public void getCardPointsTest() {
		Assert.assertEquals(CardRank.TWO.getRankValuePoint(), testCard1.getCardPoints().intValue());
		Assert.assertEquals(CardRank.TEN.getRankValuePoint(), testCard2.getCardPoints().intValue());
		Assert.assertEquals(CardRank.QUEEN.getRankValuePoint(), testCard3.getCardPoints().intValue());
		Assert.assertEquals(CardRank.ACE.getRankValuePoint(), testCard4.getCardPoints().intValue());
	}

	@Test
	public void getIsSuitSameTest() {
		CardWarGame card = new CardWarGame(CardRank.SEVEN, CardsSuit.HEARTS);
		Assert.assertFalse(testCard1.checkIsSuitSame(card));
		Assert.assertFalse(testCard2.checkIsSuitSame(card));
		Assert.assertFalse(testCard3.checkIsSuitSame(card));
		Assert.assertTrue(testCard4.checkIsSuitSame(card));
	}

	@Test
	public void getIsRankSameTest() {
		CardWarGame card = new CardWarGame(CardRank.TEN, CardsSuit.CLUBS);
		Assert.assertFalse(testCard1.checkIsRankSame(card));
		Assert.assertTrue(testCard2.checkIsRankSame(card));
		Assert.assertFalse(testCard3.checkIsRankSame(card));
		Assert.assertFalse(testCard4.checkIsRankSame(card));
	}

	@Test
	public void equalsTest() {
		CardWarGame card = new CardWarGame(CardRank.QUEEN, CardsSuit.CLUBS);
		Assert.assertNotEquals(testCard1, card);
		Assert.assertNotEquals(testCard2, card);
		Assert.assertEquals(testCard3.hashCode(), card.hashCode());
		Assert.assertEquals(testCard3, card);
		Assert.assertNotEquals(testCard4, card);
		Assert.assertNotEquals(testCard4, card);

	}

	@Test
	public void toStringTest() {
		Assert.assertEquals("Two of Spades", testCard1.toString());
		Assert.assertEquals("Ten of Diamonds", testCard2.toString());
		Assert.assertEquals("Queen of Clubs", testCard3.toString());
		Assert.assertEquals("Ace of Hearts", testCard4.toString());
	}
}
