package cardwargame;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

public class PlayerHandTest {
	private static final CardWarGame testCard1 = new CardWarGame(CardRank.TWO, CardsSuit.SPADES);
	private static final CardWarGame testCard2 = new CardWarGame(CardRank.TEN, CardsSuit.DIAMONDS);
	private static final CardWarGame testCard3 = new CardWarGame(CardRank.QUEEN, CardsSuit.CLUBS);
	private static final CardWarGame testCard4 = new CardWarGame(CardRank.ACE, CardsSuit.HEARTS);

	private static PlayerHand emptyHand;
	private static PlayerHand playerHand;

	@Before
	public void init() {
		emptyHand = new PlayerHand();
		playerHand = new PlayerHand();
		playerHand.addCardToBottom(testCard1);
		playerHand.addCardToBottom(testCard2);
		playerHand.addCardToBottom(testCard3);
		playerHand.addCardToBottom(testCard4);
	}

	@Test
	public void testSizeOfHand() {
		Assert.assertEquals(0, emptyHand.sizeofHand());
		Assert.assertEquals(4, playerHand.sizeofHand());
	}

	@Test
	public void removeCardFromBottomOfDeckTest() {
		Assert.assertEquals(testCard4, playerHand.removeCardFromBottomOfDeck());
		List<CardWarGame> cards = playerHand.takeCards(3);
		Assert.assertEquals(testCard1, cards.get(0));
		Assert.assertEquals(testCard2, cards.get(1));
		Assert.assertEquals(testCard3, cards.get(2));
	}

	@Test
	public void removeCardFromTopOfDeckTest() {
		Assert.assertEquals(testCard1, playerHand.removeCardFromTopOfDeck());
		List<CardWarGame> cards = playerHand.takeCards(3);
		Assert.assertEquals(testCard2, cards.get(0));
		Assert.assertEquals(testCard3, cards.get(1));
		Assert.assertEquals(testCard4, cards.get(2));
	}

	@Test
	public void addCardToBottomTest() {
		CardWarGame card1 = new CardWarGame(CardRank.THREE, CardsSuit.HEARTS);
		playerHand.addCardToBottom(card1);
		List<CardWarGame> cards = playerHand.takeCards(5);
		Assert.assertEquals(testCard1, cards.get(0));
		Assert.assertEquals(testCard2, cards.get(1));
		Assert.assertEquals(testCard3, cards.get(2));
		Assert.assertEquals(testCard4, cards.get(3));
		Assert.assertEquals(card1, cards.get(4));
	}

	@Test
	public void addCardToTopTest() {
		CardWarGame card1 = new CardWarGame(CardRank.THREE, CardsSuit.HEARTS);
		playerHand.addCardToTop(card1);
		List<CardWarGame> cards = playerHand.takeCards(5);
		Assert.assertEquals(card1, cards.get(0));
		Assert.assertEquals(testCard1, cards.get(1));
		Assert.assertEquals(testCard2, cards.get(2));
		Assert.assertEquals(testCard3, cards.get(3));
		Assert.assertEquals(testCard4, cards.get(4));
	}

	@Test
	public void addCardsToTopTest() {
		CardWarGame card1 = new CardWarGame(CardRank.THREE, CardsSuit.HEARTS);
		CardWarGame card2 = new CardWarGame(CardRank.KING, CardsSuit.DIAMONDS);
		playerHand.addCardsToTop(Arrays.asList(card1, card2));
		List<CardWarGame> cards = playerHand.takeCards(6);
		Assert.assertEquals(card2, cards.get(0));
		Assert.assertEquals(card1, cards.get(1));
		Assert.assertEquals(testCard1, cards.get(2));
		Assert.assertEquals(testCard2, cards.get(3));
		Assert.assertEquals(testCard3, cards.get(4));
		Assert.assertEquals(testCard4, cards.get(5));
	}

	@Test
	public void mergeHandCardsTest() {
		emptyHand.mergeHandCards(playerHand);
		List<CardWarGame> cards = emptyHand.takeCards(4);
		Assert.assertEquals(testCard4, cards.get(0));
		Assert.assertEquals(testCard3, cards.get(1));
		Assert.assertEquals(testCard2, cards.get(2));
		Assert.assertEquals(testCard1, cards.get(3));
	}
}
