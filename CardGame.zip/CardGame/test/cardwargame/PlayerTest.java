package cardwargame;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class PlayerTest {
	private static final String testName = "testName";
	private static final CardWarGame testCard1 = new CardWarGame(CardRank.TWO, CardsSuit.SPADES);
	private static final CardWarGame testCard2 = new CardWarGame(CardRank.TEN, CardsSuit.DIAMONDS);
	private static final CardWarGame testCard3 = new CardWarGame(CardRank.QUEEN, CardsSuit.CLUBS);
	private static final CardWarGame testCard4 = new CardWarGame(CardRank.ACE, CardsSuit.HEARTS);
	private static PlayerHand playerHand;
	private static Player player;

	@Before
	public void init() {
		player = new Player(testName);
		playerHand = new PlayerHand();
		playerHand.addCardToBottom(testCard1);
		playerHand.addCardToBottom(testCard2);
		playerHand.addCardToBottom(testCard3);
		playerHand.addCardToBottom(testCard4);
		player.setHand(playerHand);
	}

	@Test
	public void getNameTest() {
		Assert.assertEquals(testName, player.getPlayerName());
	}

	@Test
	public void getPlayerHandTest() {
		Assert.assertSame(playerHand, player.getHand());
	}
}
