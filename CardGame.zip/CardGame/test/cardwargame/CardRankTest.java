package cardwargame;


import org.junit.Assert;
import org.junit.Test;

public class CardRankTest {
	@Test
	public void getRankNameTest() {
		Assert.assertEquals("Two", CardRank.TWO.getRankName());
		Assert.assertEquals("Three", CardRank.THREE.getRankName());
		Assert.assertEquals("Four", CardRank.FOUR.getRankName());
		Assert.assertEquals("Five", CardRank.FIVE.getRankName());
		Assert.assertEquals("Six", CardRank.SIX.getRankName());
		Assert.assertEquals("Seven", CardRank.SEVEN.getRankName());
		Assert.assertEquals("Eight", CardRank.EIGHT.getRankName());
		Assert.assertEquals("Nine", CardRank.NINE.getRankName());
		Assert.assertEquals("Ten", CardRank.TEN.getRankName());
		Assert.assertEquals("Jack", CardRank.JACK.getRankName());
		Assert.assertEquals("Queen", CardRank.QUEEN.getRankName());
		Assert.assertEquals("King", CardRank.KING.getRankName());
		Assert.assertEquals("Ace", CardRank.ACE.getRankName());
	}

	@Test
	public void getRankValuePointTest() {
		Assert.assertEquals(2, CardRank.TWO.getRankValuePoint());
		Assert.assertEquals(3, CardRank.THREE.getRankValuePoint());
		Assert.assertEquals(4, CardRank.FOUR.getRankValuePoint());
		Assert.assertEquals(5, CardRank.FIVE.getRankValuePoint());
		Assert.assertEquals(6, CardRank.SIX.getRankValuePoint());
		Assert.assertEquals(7, CardRank.SEVEN.getRankValuePoint());
		Assert.assertEquals(8, CardRank.EIGHT.getRankValuePoint());
		Assert.assertEquals(9, CardRank.NINE.getRankValuePoint());
		Assert.assertEquals(10, CardRank.TEN.getRankValuePoint());
		Assert.assertEquals(11, CardRank.JACK.getRankValuePoint());
		Assert.assertEquals(12, CardRank.QUEEN.getRankValuePoint());
		Assert.assertEquals(13, CardRank.KING.getRankValuePoint());
		Assert.assertEquals(14, CardRank.ACE.getRankValuePoint());
	}

	@Test
	public void toStringTest() {
		Assert.assertEquals("2", CardRank.TWO.toString());
		Assert.assertEquals("3", CardRank.THREE.toString());
		Assert.assertEquals("4", CardRank.FOUR.toString());
		Assert.assertEquals("5", CardRank.FIVE.toString());
		Assert.assertEquals("6", CardRank.SIX.toString());
		Assert.assertEquals("7", CardRank.SEVEN.toString());
		Assert.assertEquals("8", CardRank.EIGHT.toString());
		Assert.assertEquals("9", CardRank.NINE.toString());
		Assert.assertEquals("10", CardRank.TEN.toString());
		Assert.assertEquals("J", CardRank.JACK.toString());
		Assert.assertEquals("Q", CardRank.QUEEN.toString());
		Assert.assertEquals("K", CardRank.KING.toString());
		Assert.assertEquals("A", CardRank.ACE.toString());
	}
}
