package cardwargame;

import org.junit.Assert;
import org.junit.Test;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CardDeckTest {
	@Test
	public void createDeckTest() {
		CardsDeck deck = new CardsDeck();
		List<CardWarGame> cards = deck.getGameCards();
		Set<CardWarGame> diffCards = new HashSet<>(cards);
		Assert.assertEquals(52, diffCards.size());
	}

	@Test
	public void getCardsCountTest() {
		CardsDeck deck = new CardsDeck();
		Assert.assertEquals(52, deck.getCardsCount());
	}

	@Test
	public void dealCardFromTopTest() {
		CardsDeck deck = new CardsDeck();

		List<CardWarGame> cardsBefore = deck.getGameCards();
		CardWarGame top = cardsBefore.get(51);
		CardWarGame dealed = deck.dealCardFromTop();
		List<CardWarGame> cardsAfter = deck.getGameCards();

		Assert.assertEquals(top, dealed);
		for(int i = 0; i<51; i++) {
			Assert.assertEquals(cardsBefore.get(i), cardsAfter.get(i));
		}
	}
}
