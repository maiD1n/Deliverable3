package cardwargame;


import org.junit.Assert;
import org.junit.Test;

public class CardSuitTest {
	@Test
	public void getSuitSymbolTest() {
		Assert.assertEquals("S", CardsSuit.SPADES.getSuitSymbol());
		Assert.assertEquals("D", CardsSuit.DIAMONDS.getSuitSymbol());
		Assert.assertEquals("C", CardsSuit.CLUBS.getSuitSymbol());
		Assert.assertEquals("H", CardsSuit.HEARTS.getSuitSymbol());
	}

	@Test
	public void getSuitNameTest() {
		Assert.assertEquals("Spades", CardsSuit.SPADES.getSuitName());
		Assert.assertEquals("Diamonds", CardsSuit.DIAMONDS.getSuitName());
		Assert.assertEquals("Clubs", CardsSuit.CLUBS.getSuitName());
		Assert.assertEquals("Hearts", CardsSuit.HEARTS.getSuitName());
	}

	@Test
	public void toStringTest() {
		Assert.assertEquals("S", CardsSuit.SPADES.toString());
		Assert.assertEquals("D", CardsSuit.DIAMONDS.toString());
		Assert.assertEquals("C", CardsSuit.CLUBS.toString());
		Assert.assertEquals("H", CardsSuit.HEARTS.toString());
	}
}
